
public class DiveFlip implements DiveBehavior {
    public void dive() {
        System.out.println("I'm doing a flip dive!");
    }
}