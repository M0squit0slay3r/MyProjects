
public interface DiveBehavior {
    void dive();
}