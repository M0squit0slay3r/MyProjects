// from felix -- the interface that all flying behaviour classes implement 
public interface FlyBehavior {
    void fly();
}