public class DiveTwist implements DiveBehavior {
    public void dive() {
        System.out.println("I'm doing a twist dive!");
    }
}